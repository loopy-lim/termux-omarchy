#ifndef FREERDP_CONFIG_H
#define FREERDP_CONFIG_H

#include <winpr/config.h>

/* Include files */
/* #undef FREERDP_HAVE_VALGRIND_MEMCHECK_H */

/* Features */
#define SWRESAMPLE_FOUND
/* #undef AVRESAMPLE_FOUND */

/* Options */
/** If set the rdpSettings struct is opaque and internals can only be accessed
 *  through getters/setters
 *
 *  \since version 3.0.0
 */
/* #undef WITH_OPAQUE_SETTINGS */

/* #undef WITH_ADD_PLUGIN_TO_RPATH */
/* #undef WITH_PROFILER */
/* #undef WITH_GPROF */
#define WITH_SIMD
#define WITH_AVX2
#define WITH_CUPS
#define WITH_JPEG
/* #undef WITH_WIN8 */
#define WITH_AAD
/* #undef WITH_CAIRO */
#define WITH_SWSCALE
/* #undef WITH_SWSCALE_LOADING */
/* #undef WITH_RDPSND_DSOUND */

/* #undef WITH_WINMM */
/* #undef WITH_MACAUDIO */
#define WITH_OSS
#define WITH_ALSA
#define WITH_PULSE
/* #undef WITH_IOSAUDIO */
/* #undef WITH_OPENSLES */
/* #undef WITH_AAUDIO */
/* #undef WITH_GSM */
/* #undef WITH_LAME */
/** If defined Opus codec support is available.
 *
 *  \since version 3.0.0
 */
/* #undef WITH_OPUS */
/* #undef WITH_FAAD2 */
/* #undef WITH_FAAC */
/* #undef WITH_SOXR */
#define WITH_GFX_H264
/* #undef WITH_OPENH264 */
/* #undef WITH_OPENH264_LOADING */
#define WITH_VIDEO_FFMPEG
/* #undef WITH_DSP_EXPERIMENTAL */
#define WITH_DSP_FFMPEG
/* #undef WITH_OPENCL */
/* #undef WITH_MEDIA_FOUNDATION */
/* #undef WITH_MEDIACODEC */
/* #undef WITH_GFX_AV1 */

/* #undef WITH_FFMPEG_HWACCEL */

#define WITH_CHANNELS
#define WITH_CLIENT_CHANNELS
#define WITH_SERVER_CHANNELS

/* #undef WITH_CHANNEL_GFXREDIR */
/* #undef WITH_CHANNEL_RDPAPPLIST */

/* Plugins */
/* #undef WITH_RDPDR */

/* Channels */
#define CHANNEL_AINPUT
#define CHANNEL_AINPUT_CLIENT
#define CHANNEL_AINPUT_SERVER
#define CHANNEL_AUDIN
#define CHANNEL_AUDIN_CLIENT
#define CHANNEL_AUDIN_SERVER
#define CHANNEL_CLIPRDR
#define CHANNEL_CLIPRDR_CLIENT
#define CHANNEL_CLIPRDR_SERVER
#define CHANNEL_DISP
#define CHANNEL_DISP_CLIENT
#define CHANNEL_DISP_SERVER
#define CHANNEL_DRDYNVC
#define CHANNEL_DRDYNVC_CLIENT
#define CHANNEL_DRDYNVC_SERVER
#define CHANNEL_DRIVE
#define CHANNEL_DRIVE_CLIENT
/* #undef CHANNEL_DRIVE_SERVER */

#define CHANNEL_ECHO
#define CHANNEL_ECHO_CLIENT
#define CHANNEL_ECHO_SERVER
#define CHANNEL_ENCOMSP
#define CHANNEL_ENCOMSP_CLIENT
#define CHANNEL_ENCOMSP_SERVER
#define CHANNEL_GEOMETRY
#define CHANNEL_GEOMETRY_CLIENT
/* #undef CHANNEL_GEOMETRY_SERVER */
/* #undef CHANNEL_GFXREDIR */
/* #undef CHANNEL_GFXREDIR_CLIENT */
/* #undef CHANNEL_GFXREDIR_SERVER */
/** If defined location channel support is available.
 *
 *  \since version 3.0.0
 */
#define CHANNEL_LOCATION
/** If defined location client side channel support is available.
 *
 *  \since version 3.0.0
 */
#define CHANNEL_LOCATION_CLIENT
/** If defined location server side channel support is available.
 *
 *  \since version 3.0.0
 */
#define CHANNEL_LOCATION_SERVER
#define CHANNEL_PARALLEL
#define CHANNEL_PARALLEL_CLIENT
/* #undef CHANNEL_PARALLEL_SERVER */
#define CHANNEL_PRINTER
#define CHANNEL_PRINTER_CLIENT
/* #undef CHANNEL_PRINTER_SERVER */
#define CHANNEL_RAIL
#define CHANNEL_RAIL_CLIENT
#define CHANNEL_RAIL_SERVER
/* #undef CHANNEL_RDPAPPLIST */
/* #undef CHANNEL_RDPAPPLIST_CLIENT */
/* #undef CHANNEL_RDPAPPLIST_SERVER */
#define CHANNEL_RDPDR
#define CHANNEL_RDPDR_CLIENT
#define CHANNEL_RDPDR_SERVER
#define CHANNEL_RDPECAM
#define CHANNEL_RDPECAM_CLIENT
#define CHANNEL_RDPECAM_SERVER
/* #undef CHANNEL_RDPEAR */
/* #undef CHANNEL_RDPEAR_CLIENT */
/* #undef CHANNEL_RDPEAR_SERVER */
#define CHANNEL_RDPEWA
#define CHANNEL_RDPEWA_CLIENT
/* #undef CHANNEL_RDPEWA_SERVER */
#define CHANNEL_RDPEI
#define CHANNEL_RDPEI_CLIENT
#define CHANNEL_RDPEI_SERVER
#define CHANNEL_RDPGFX
#define CHANNEL_RDPGFX_CLIENT
#define CHANNEL_RDPGFX_SERVER
/** If defined mouse cursor channel support is available.
 *
 *  \since version 3.0.0
 */
#define CHANNEL_RDPEMSC

/** If defined mouse cursor channel support is available.
 *
 *  \since version 3.0.0
 */
/* #undef CHANNEL_RDPEMSC_CLIENT */

/** If defined mouse cursor channel support is available.
 *
 *  \since version 3.0.0
 */
#define CHANNEL_RDPEMSC_SERVER
#define CHANNEL_RDPSND
#define CHANNEL_RDPSND_CLIENT
#define CHANNEL_RDPSND_SERVER
#define CHANNEL_REMDESK
#define CHANNEL_REMDESK_CLIENT
#define CHANNEL_REMDESK_SERVER
#define CHANNEL_SERIAL
#define CHANNEL_SERIAL_CLIENT
/* #undef CHANNEL_SERIAL_SERVER */
#define CHANNEL_SMARTCARD
#define CHANNEL_SMARTCARD_CLIENT
/* #undef CHANNEL_SMARTCARD_SERVER */
/* #undef CHANNEL_SSHAGENT */
/* #undef CHANNEL_SSHAGENT_CLIENT */
/* #undef CHANNEL_SSHAGENT_SERVER */
#define CHANNEL_TELEMETRY
/* #undef CHANNEL_TELEMETRY_CLIENT */
#define CHANNEL_TELEMETRY_SERVER
/* #undef CHANNEL_TSMF */
/* #undef CHANNEL_TSMF_CLIENT */
/* #undef CHANNEL_TSMF_SERVER */
#define CHANNEL_URBDRC
#define CHANNEL_URBDRC_CLIENT
/* #undef CHANNEL_URBDRC_SERVER */
#define CHANNEL_VIDEO
#define CHANNEL_VIDEO_CLIENT
/* #undef CHANNEL_VIDEO_SERVER */

/* Debug */
/* #undef WITH_DEBUG_CERTIFICATE */
/* #undef WITH_DEBUG_CAPABILITIES */
/* #undef WITH_DEBUG_CHANNELS */
/* #undef WITH_DEBUG_CLIPRDR */
/* #undef WITH_DEBUG_CODECS */
/* #undef WITH_DEBUG_RDPGFX */
/* #undef WITH_DEBUG_DVC */
/* #undef WITH_DEBUG_TSMF */
/* #undef WITH_DEBUG_KBD */
/* #undef WITH_DEBUG_LICENSE */
/* #undef WITH_DEBUG_NEGO */
/* #undef WITH_DEBUG_NLA */
/* #undef WITH_DEBUG_TSG */
/* #undef WITH_DEBUG_RAIL */
/* #undef WITH_DEBUG_RDP */
/* #undef WITH_DEBUG_REDIR */
/* #undef WITH_DEBUG_RDPDR */
/* #undef WITH_DEBUG_RFX */
/* #undef WITH_DEBUG_SCARD */
/* #undef WITH_DEBUG_SND */
/* #undef WITH_DEBUG_SVC */
/* #undef WITH_DEBUG_RDPEI */
/* #undef WITH_DEBUG_TIMEZONE */
/* #undef WITH_DEBUG_URBDRC */
/* #undef WITH_DEBUG_TRANSPORT */
/* #undef WITH_DEBUG_WND */
/* #undef WITH_DEBUG_RINGBUFFER */

/* Proxy */
#define WITH_PROXY_MODULES
/* #undef WITH_PROXY_EMULATE_SMARTCARD */

/** If defined linux/vm_sockets.h support is available.
 *
 *  \since version 3.0.0
 */
#define HAVE_AF_VSOCK_H

/** If library is build without these do permanently hide symbols
 *
 * \since version 3.17.2
 */
#if !defined(WITHOUT_FREERDP_3x_DEPRECATED)
/* #undef WITHOUT_FREERDP_3x_DEPRECATED */
#endif

/** Build FILE_DIRECTORY_INFORMATION::FileName with type WCHAR instead of char
 *
 * @since version 3.20.0
 */
/* #undef WITH_WCHAR_FILE_DIRECTORY_INFORMATION */

/** Enforce the TLS AEAD cryptographic data limit (RFC 8446 §5.5): on a TLS 1.3
 *  connection the traffic keys are rekeyed in place once a per-direction byte
 *  threshold is reached; if the rekey fails the connection is cut. On non-TLS-1.3
 *  connections a rekey is not possible and the connection is left as is. When
 *  undefined the whole feature is compiled out.
 * @since version 3.31.0
 */
/* #undef WITH_TLS_DATA_LIMIT */

#endif /* FREERDP_CONFIG_H */
