#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "freerdp-shadow" for configuration "Release"
set_property(TARGET freerdp-shadow APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(freerdp-shadow PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "freerdp-server;winpr-tools"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libfreerdp-shadow3.so.3.32.1"
  IMPORTED_SONAME_RELEASE "libfreerdp-shadow3.so.3"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow )
list(APPEND _cmake_import_check_files_for_freerdp-shadow "${_IMPORT_PREFIX}/lib/libfreerdp-shadow3.so.3.32.1" )

# Import target "freerdp-shadow-subsystem" for configuration "Release"
set_property(TARGET freerdp-shadow-subsystem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(freerdp-shadow-subsystem PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "freerdp-server;winpr-tools;freerdp-shadow;freerdp;winpr"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libfreerdp-shadow-subsystem3.so.3.32.1"
  IMPORTED_SONAME_RELEASE "libfreerdp-shadow-subsystem3.so.3"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow-subsystem )
list(APPEND _cmake_import_check_files_for_freerdp-shadow-subsystem "${_IMPORT_PREFIX}/lib/libfreerdp-shadow-subsystem3.so.3.32.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
